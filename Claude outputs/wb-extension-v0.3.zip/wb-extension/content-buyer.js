// Content-скрипт для обычной страницы товара (как её видит покупатель). Достаёт
// артикул из адреса страницы, спрашивает у фонового процесса готовый СПП по этому
// товару (см. background.js — там и запрос к Wildberries за ценой на сайте, и запрос
// к серверу MarketRadar за ценой продавца) и рисует значок рядом с ценой.
//
// Если товар не найден среди своих (сервер отвечает "не синхронизирован") — это чужой
// товар или ещё не подтянутый в MarketRadar; значок просто не показываем, ничего не
// ломаем.

const LOG_PREFIX = "[MarketRadar СПП]";

function log(...args) {
  console.log(LOG_PREFIX, ...args);
}

function getArticleFromUrl() {
  const match = window.location.pathname.match(/\/catalog\/(\d+)\//);
  return match ? match[1] : null;
}

function createBadge(sppPercent) {
  const badge = document.createElement("span");
  badge.className = "marketradar-spp-badge";
  badge.textContent = `СПП: ${sppPercent.toFixed(1)}%`;
  return badge;
}

function createErrorBadge(message) {
  const badge = document.createElement("span");
  badge.className = "marketradar-spp-badge marketradar-spp-badge--error";
  badge.title = message;
  badge.textContent = "СПП: н/д";
  return badge;
}

function findPriceElement() {
  // Несколько известных вариантов вёрстки страницы товара — если ни один не сработает,
  // это будет видно в логе консоли (см. README, как прислать эти сообщения).
  const selectors = [
    ".price-block__final-price",
    "[data-testid='price-final']",
    ".product-page__price-block .price-block__final-price",
  ];
  for (const selector of selectors) {
    const el = document.querySelector(selector);
    if (el) return el;
  }
  return null;
}

function requestSpp(nm) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "GET_SPP_FOR_PRODUCT", nm }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response);
    });
  });
}

let processedNm = null;

async function run() {
  const nm = getArticleFromUrl();
  if (!nm) return;
  if (nm === processedNm) return; // не повторяем запрос и не дублируем значок
  const priceElement = findPriceElement();
  if (!priceElement) return; // подождём, пока цена появится в DOM
  processedNm = nm;

  let response;
  try {
    response = await requestSpp(nm);
  } catch (err) {
    log(`Артикул ${nm}: не удалось связаться с фоновым процессом —`, err.message);
    return;
  }

  if (!response?.ok) {
    if (response?.code === "NO_KEY") {
      log("Ключ расширения не задан — откройте попап расширения и вставьте ключ со страницы Настроек MarketRadar.");
      return;
    }
    if (response?.code === "NOT_SYNCED") {
      log(`Артикул ${nm}: ${response.error} (или это не ваш товар)`);
      return;
    }
    log(`Артикул ${nm}: ошибка —`, response?.error);
    const el = findPriceElement();
    if (el) el.insertAdjacentElement("afterend", createErrorBadge(response?.error || "неизвестная ошибка"));
    return;
  }

  log(
    `Артикул ${nm}: цена продавца ${response.sellerPrice}, цена на сайте ${response.sitePrice}, ` +
      `СПП ${response.sppPercent}%`
  );
  const el = findPriceElement();
  if (el) el.insertAdjacentElement("afterend", createBadge(response.sppPercent));
}

log("Скрипт загружен на странице товара, ищу цену...");

// Страница товара одностраничная — следим за изменениями DOM на случай, если цена
// подгружается не сразу.
const observer = new MutationObserver(() => run());
observer.observe(document.body, { childList: true, subtree: true });

run();
