const statusEl = document.getElementById("status");
const keyInput = document.getElementById("key-input");
const saveBtn = document.getElementById("save-btn");
const savedMsg = document.getElementById("saved-msg");

async function refresh() {
  const { extKey } = await chrome.storage.local.get("extKey");
  if (extKey) {
    statusEl.textContent = "Ключ сохранён — расширение подключено к MarketRadar.";
    statusEl.className = "ok";
    keyInput.value = extKey;
  } else {
    statusEl.textContent = "Ключ ещё не задан.";
    statusEl.className = "bad";
  }
}

saveBtn.addEventListener("click", async () => {
  const key = keyInput.value.trim();
  if (!key) return;
  await chrome.storage.local.set({ extKey: key });
  savedMsg.style.display = "block";
  setTimeout(() => (savedMsg.style.display = "none"), 2000);
  await refresh();
});

refresh();
