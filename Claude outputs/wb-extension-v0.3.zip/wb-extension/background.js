// Фоновый сервис-воркер расширения. Делает все сетевые запросы — и к самому
// Wildberries (получить текущую цену на сайте по артикулу через тот же публичный
// JSON, что использует сама страница товара), и к серверу MarketRadar (узнать
// сохранённую цену продавца и записать увиденную цену на сайте в историю).
// Content-скрипт (content-buyer.js) сам эти запросы сделать не может — межсайтовые
// запросы к чужим доменам блокирует CORS. У background-процесса расширения этого
// ограничения нет: нужные домены разрешены в manifest.json (host_permissions), и
// браузер доверяет это расширению, а не обычному сайту.
//
// ВАЖНО: с версии 0.3 расширение больше не читает цену продавца со страницы
// "Цены и скидки" в кабинете — она уже посчитана официальным API Wildberries на
// сервере MarketRadar при обычной синхронизации (см. server.js →
// src/syncService.js → src/wbClient.js). Расширению остаётся только увидеть цену
// на сайте (это может сделать только настоящий браузер продавца — датацентровые IP
// самого сервера WB блокирует, см. README) и прислать её на сервер.

const DEFAULT_DEST = "-1257786"; // Москва — для расчёта СПП конкретный регион почти не важен
const API_BASE = "https://marketradar-1-ibdh.onrender.com";

async function fetchBuyerPrice(nm, dest = DEFAULT_DEST) {
  const url =
    `https://card.wb.ru/cards/v4/detail?appType=1&curr=rub&dest=${dest}` +
    `&hide_dtype=13&spp=30&ab_testing=false&lang=ru&nm=${nm}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Wildberries вернул ${res.status}`);
  const json = await res.json();
  const product = json?.products?.[0] ?? json?.data?.products?.[0];
  if (!product) throw new Error("Товар не найден в ответе Wildberries");
  const price =
    product.sizes?.[0]?.price?.product ??
    product.sizes?.[0]?.price?.total ??
    product.salePriceU ??
    product.priceU;
  if (price == null) throw new Error("Не удалось найти цену в ответе Wildberries");
  return price / 100; // копейки → рубли
}

async function getExtensionKey() {
  const { extKey } = await chrome.storage.local.get("extKey");
  return extKey || null;
}

async function reportPriceToServer(nmId, sitePrice) {
  const key = await getExtensionKey();
  if (!key) {
    const err = new Error(
      "Ключ расширения не задан — откройте попап расширения и вставьте ключ со страницы Настроек MarketRadar"
    );
    err.code = "NO_KEY";
    throw err;
  }

  const res = await fetch(`${API_BASE}/api/ext/site-price`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-MarketRadar-Key": key },
    body: JSON.stringify({ nmId, sitePrice }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `Сервер MarketRadar вернул ${res.status}`);
    err.code = res.status === 404 ? "NOT_SYNCED" : res.status === 401 ? "NO_KEY" : "SERVER_ERROR";
    throw err;
  }
  return data; // { sellerPrice, sitePrice, sppPercent }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_SPP_FOR_PRODUCT") {
    (async () => {
      try {
        const buyerPrice = await fetchBuyerPrice(message.nm, message.dest);
        const result = await reportPriceToServer(Number(message.nm), buyerPrice);
        sendResponse({ ok: true, ...result });
      } catch (err) {
        sendResponse({ ok: false, error: err.message, code: err.code || "UNKNOWN" });
      }
    })();
    return true; // отвечаем асинхронно
  }
});
